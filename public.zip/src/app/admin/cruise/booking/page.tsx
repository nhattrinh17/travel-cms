import { BookingCruiseSection } from '@/sections/cruise/booking';

export default function BookingCruisePage(): JSX.Element {
  return <BookingCruiseSection />;
}
