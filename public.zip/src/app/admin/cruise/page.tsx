import { CruiseManageSection } from '@/sections/cruise/manage';

export default function ManageCruise(): JSX.Element {
  return <CruiseManageSection />;
}
