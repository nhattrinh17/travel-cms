export default function AdminHome() {
  return (
    <main className="min-h-screen p-24">
      <h1 className="text-4xl font-bold text-center">Welcome to Game CMS</h1>
    </main>
  );
}
