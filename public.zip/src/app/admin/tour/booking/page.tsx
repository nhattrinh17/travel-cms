import { BookingTourSection } from '@/sections/tour/booking';

export default function BookingTourPage(): JSX.Element {
  return <BookingTourSection />;
}
