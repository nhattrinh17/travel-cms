import { TourManageSection } from '@/sections/tour/manage';

export default function TourHomePage(): JSX.Element {
  return <TourManageSection />;
}
