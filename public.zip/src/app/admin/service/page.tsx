import { ServiceSection } from '@/sections/service';

export default function ServicePage(): JSX.Element {
  return <ServiceSection />;
}
